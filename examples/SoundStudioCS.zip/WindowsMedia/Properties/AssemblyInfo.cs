﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Security.Permissions;

// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
[assembly: AssemblyTitle("WindowsMedia")]
[assembly: AssemblyDescription("WindowsMedia and Directshow library (RC)")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Ernzo.com")]
[assembly: AssemblyProduct("WindowsMedia")]
[assembly: AssemblyCopyright("Copyright © 2008 - www.ernzo.com")]
[assembly: AssemblyTrademark("")]

[assembly: System.CLSCompliant(true)]
[assembly: SecurityPermission(SecurityAction.RequestMinimum, UnmanagedCode = true)]

// Setting ComVisible to false makes the types in this assembly not visible 
// to COM components.  If you need to access a type in this assembly from 
// COM, set the ComVisible attribute to true on that type.
[assembly: ComVisible(false)]

// The following GUID is for the ID of the typelib if this project is exposed to COM
[assembly: Guid("caabbc33-a3f4-4574-ad3b-545cbd5a45c1")]

// Version information for an assembly consists of the following four values:
//
//      Major Version
//      Minor Version 
//      Build Number
//      Revision
//
// You can specify all the values or you can default the Revision and Build Numbers 
// by using the '*' as shown below:
[assembly: AssemblyVersion("1.0.0.2")]
[assembly: AssemblyFileVersion("1.0.0.2")]
